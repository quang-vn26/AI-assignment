"""
This script processes a batch of requests to the Azure OpenAI service
to generate travel itineraries using function calling.

It includes features like automatic retries for API errors and rate limits.
"""

import os
import time
import json
import logging
import logging.handlers
from typing import List, Dict, Any, Optional
from dotenv import load_dotenv, dotenv_values 
load_dotenv() 
from openai import AzureOpenAI

# Configure logging with both file and console output
# Get the current script directory
script_dir = os.path.dirname(os.path.abspath(__file__))
log_directory = os.path.join(script_dir, "logs")
if not os.path.exists(log_directory):
    os.makedirs(log_directory)

log_file = os.path.join(log_directory, "travel_itinerary.log")

# Clear existing log file if it exists
if os.path.exists(log_file):
    open(log_file, 'w').close()
    logging.info("Cleared previous log file")

# Custom formatter class with colors for console output
class ColorFormatter(logging.Formatter):
    """Custom formatter adding colors to levelname for console output"""
    
    COLORS = {
        'DEBUG': '\033[0;36m',  # Cyan
        'INFO': '\033[0;32m',   # Green
        'WARNING': '\033[0;33m', # Yellow
        'ERROR': '\033[0;31m',   # Red
        'CRITICAL': '\033[0;37;41m',  # White on Red
        'RESET': '\033[0m'      # Reset
    }
    
    def format(self, record):
        # Save original levelname
        original_levelname = record.levelname
        # Add colors if this is a console handler
        if record.levelname in self.COLORS:
            record.levelname = f"{self.COLORS[record.levelname]}{record.levelname:8}{self.COLORS['RESET']}"
        
        # Format message with additional context
        formatted_msg = super().format(record)
        # Restore original levelname
        record.levelname = original_levelname
        return formatted_msg

# Use RotatingFileHandler to manage log file size (5MB per file, keep 5 backup files)
file_handler = logging.handlers.RotatingFileHandler(
    log_file,
    maxBytes=5*1024*1024,  # 5MB
    backupCount=5,
    encoding='utf-8'
)
console_handler = logging.StreamHandler()

# Define rich format for both handlers
file_format = logging.Formatter(
    fmt='%(asctime)s | %(levelname)-8s | %(funcName)s:%(lineno)d | %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

console_format = ColorFormatter(
    fmt='%(asctime)s │ %(levelname)s │ %(funcName)s:%(lineno)d │ %(message)s',
    datefmt='%H:%M:%S'
)

file_handler.setFormatter(file_format)
console_handler.setFormatter(console_format)

# Get the root logger and add handlers
logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.addHandler(file_handler)
logger.addHandler(console_handler)

logging.info(f"Starting application, logging to {log_file}")

# Third-party libraries
from openai import AzureOpenAI, RateLimitError, APIError
from tenacity import (
    retry,
    stop_after_attempt,
    wait_random_exponential,
    retry_if_exception_type,
)

# --- 1. Configuration ---
API_VERSION = "2024-07-01-preview"

# It's recommended to load sensitive data from environment variables
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_DEPLOYMENT_NAME = os.getenv("AZURE_DEPLOYMENT_NAME", "GPT-4o-mini")

# Validate that essential configuration is set
if not all([AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY]):
    raise ValueError(
        "Azure OpenAI credentials (ENDPOINT, API_KEY) are not set in environment variables."
    )

# --- 2. Azure OpenAI Client Initialization ---
client = AzureOpenAI(
    api_version=API_VERSION,
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
)

# --- 3. Function Calling Schema ---
# Defines the structure of the function the model can call.
ITINERARY_FUNCTION_SCHEMA = [
    {
        "name": "generate_itinerary",
        "description": "Generate a travel itinerary for a given destination and duration.",
        "parameters": {
            "type": "object",
            "properties": {
                "destination": {
                    "type": "string",
                    "description": "Travel destination city or country (e.g., 'Paris', 'Japan').",
                },
                "days": {
                    "type": "integer",
                    "description": "Number of days for the itinerary.",
                },
                "itinerary": {
                    "type": "string",
                    "description": "A detailed day-by-day itinerary plan formatted as markdown text."
                }
            },
            "required": ["destination", "days", "itinerary"],
        },
    }
]


# --- 4. Core Functions ---
@retry(
    retry=retry_if_exception_type((RateLimitError, APIError)),
    wait=wait_random_exponential(min=1, max=10),
    stop=stop_after_attempt(5),
    reraise=True,
)
def call_openai_function(prompt: str, destination: str, days: int) -> Any:
    """
    Calls the Azure OpenAI API with a specific function and arguments.

    This function automatically retries on transient API errors and rate limits.

    Args:
        prompt (str): The user prompt for the chat completion.
        destination (str): The destination for the itinerary.
        days (int): The number of days for the itinerary.

    Returns:
        The response object from the OpenAI API call.
    """
    logging.info(f"🌍 Processing itinerary request for {destination}")

    # Construct system message to guide the model
    system_message = """You are a travel planning assistant. Your task is to generate detailed travel itineraries.
    YOU MUST use the generate_itinerary function to provide your response.
    Include activities, attractions, timings, and food recommendations for each day.
    Format the itinerary as a clear markdown document with day-by-day sections."""

    # Enhanced prompt with specific instructions
    enhanced_prompt = f"""Create a detailed {days}-day itinerary for {destination}.
    Include for each day:
    - Morning activities (9 AM - 12 PM)
    - Afternoon activities (2 PM - 5 PM)
    - Evening activities (6 PM - 9 PM)
    - Restaurant recommendations for lunch and dinner
    Focus on major attractions, cultural experiences, and local specialties.
    Format your response as a markdown document with clear headings and bullet points."""

    # Function arguments with example format
    function_arguments = {
        "destination": destination,
        "days": days,
        "itinerary": ""  # This will be filled by the model
    }

    response = client.chat.completions.create(
        model=AZURE_DEPLOYMENT_NAME,
        messages=[
            {"role": "system", "content": system_message},
            {"role": "user", "content": enhanced_prompt}
        ],
        functions=ITINERARY_FUNCTION_SCHEMA,
        function_call={
            "name": "generate_itinerary",
            "arguments": json.dumps(function_arguments)
        }
    )
    return response


def batch_process(inputs: List[Dict[str, Any]]) -> List[Optional[Any]]:
    """
    Processes a batch of itinerary requests.

    Args:
        inputs: A list of dictionaries, each containing 'prompt',
                'destination', and 'days'.

    Returns:
        A list containing the API responses or None for failed requests.
    """
    results = []
    for item in inputs:
        try:
            response = call_openai_function(
                prompt=item["prompt"],
                destination=item["destination"],
                days=item["days"],
            )
            results.append(response)
            # Optional delay to avoid hitting rate limits too aggressively
            time.sleep(1)
        except Exception as e:
            logging.error(f"❌ Error processing '{item.get('destination')}':")
            logging.error(f"   └─ Details: {str(e)}")
            results.append(None)  # Maintain list order on failure
    return results


# --- 5. Main Execution Block ---
def main():
    """
    Defines batch inputs, runs the processing, and displays the results.
    """
    # Example batch inputs
    batch_inputs = [
        {"prompt": "Plan a travel itinerary.", "destination": "Paris", "days": 3},
        {"prompt": "Give me a trip plan.", "destination": "Tokyo", "days": 5},
        {"prompt": "I need an itinerary for a vacation.", "destination": "New York", "days": 4},
    ]

    outputs = batch_process(batch_inputs)

    logging.info("┌" + "─" * 48 + "┐")
    logging.info("│" + "  🎉 BATCH PROCESSING COMPLETED SUCCESSFULLY  ".center(48) + "│")
    logging.info("└" + "─" * 48 + "┘")

    # Display results alongside their original request
    for request, output in zip(batch_inputs, outputs):
        destination = request["destination"]
        logging.info(f"📍 Processing results for {destination}")
        if output and output.choices[0].message.function_call:
            function_call = output.choices[0].message.function_call
            if function_call.name == "generate_itinerary":
                # Log raw JSON response first
                logging.info("├─ Raw Response JSON:")
                logging.info("├─ " + json.dumps(json.loads(function_call.arguments), indent=2))
                
                # Parse and display formatted response
                try:
                    itinerary = json.loads(function_call.arguments)
                    logging.info("├─ Status: ✅ Success")
                    logging.info(f"├─ Destination: {itinerary['destination']}")
                    logging.info(f"├─ Duration: {itinerary['days']} days")
                    
                    # Log the formatted itinerary
                    logging.info(f"├─ Formatted Itinerary:")
                    itinerary_lines = itinerary['itinerary'].strip().split('\n')
                    for i, line in enumerate(itinerary_lines):
                        prefix = "└─ " if i == len(itinerary_lines) - 1 else "├─ "
                        logging.info(f"│  {prefix}{line}")
                except json.JSONDecodeError as e:
                    logging.error(f"├─ Error parsing response: {e}")
                    logging.error(f"└─ Raw response: {function_call.arguments}")
            else:
                logging.warning("├─ Unexpected function call")
                logging.warning(f"└─ Got: {function_call.name}")
        else:
            logging.warning("├─ Status: ❌ Failed")
            logging.warning("└─ No result or no function call in response")


if __name__ == "__main__":
    main()