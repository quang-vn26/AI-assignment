# 🌍 AI-Powered Travel Itinerary Generator

An intelligent travel planner that leverages Azure OpenAI to create detailed, personalized travel itineraries. Just specify your destination and duration to get a comprehensive travel plan!

## 🚀 Key Features

1. **Smart Itinerary Planning**:
   - Automatic selection of must-visit locations
   - Time-optimized scheduling
   - Local restaurant recommendations
   - Cultural experience integration

2. **Robust Error Handling**:
   - Automatic retry mechanism
   - Rate limit management
   - Detailed error logging

3. **Developer-Friendly**:
   - Clean code structure
   - Comprehensive logging
   - Easy configuration
   - Batch processing support

## 📋 Quick Start

1. **Install Dependencies**:
```bash
pip install -r requirements.txt
```

2. **Configure Azure OpenAI**:
Create a `.env` file with your credentials:
```env
AZURE_OPENAI_ENDPOINT=your_endpoint_here
AZURE_OPENAI_API_KEY=your_api_key_here
AZURE_DEPLOYMENT_NAME=your_model_deployment
```

3. **Run the Application**:
```bash
python assignment4.py
```

## 💡 Usage Example

## � Technical Details

1. **Azure OpenAI Integration**:
   - Function calling for structured outputs
   - Robust error handling with retries
   - Rate limit management
   - Batch processing support

2. **Code Structure**:
   - Clean modular design
   - Type hints and documentation
   - Comprehensive logging system
   - Environment validation

3. **Logging System**:
   - Colored console output
   - Rotating file logs
   - Detailed error tracking
   - JSON response logging

## ⚙️ How It Works

1. **Input Processing**:
   - Destination name
   - Duration in days
   - Special requirements (optional)

2. **AI Processing**:
   - Azure OpenAI API call
   - Function calling for structured output
   - Automatic retry mechanism

3. **Output Generation**:
   - Day-by-day itinerary
   - Time-specific activities
   - Local recommendations

## 🎯 Ví dụ Thực Tế

### Sample Inputs and Outputs
- Included inside `main()` as `batch_inputs` (three samples). The script prints a result block per destination. If an item fails after retries, it prints a friendly message instead.

## ❗ Prerequisites

1. Azure OpenAI account
2. Valid API key
3. Stable internet connection
4. Sufficient API credits

## 🔧 Troubleshooting

1. **API Key Issues**:
   - Verify `.env` file configuration
   - Check API key validity

2. **Connection Problems**:
   - Test internet connectivity
   - Validate endpoint URL

3. **Output Issues**:
   - Try reducing duration
   - Specify more precise locations

## 📝 License

MIT License - Free to use and modify

## 🤝 Contributing

Contributions, issues, and feature requests are welcome!


