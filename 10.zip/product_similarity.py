# pip install pinecone openai python-dotenv
import os
import time
from pinecone import Pinecone, ServerlessSpec
from openai import AzureOpenAI
from dotenv import load_dotenv

# --- Configuration ---
# Tải các biến môi trường từ tệp .env
load_dotenv()

# --- Main Script ---

def get_embedding(text: str, client: AzureOpenAI) -> list[float]:
    """Generates an embedding for the given text using Azure OpenAI."""
    try:
        response = client.embeddings.create(
            input=text, model=os.getenv("AZURE_DEPLOYMENT_NAME")
        )
        return response.data[0].embedding
    except Exception as e:
        print(f"Error getting embedding: {e}")
        return []

def main():
    """
    Main function to initialize Pinecone, upsert data, and run a query.
    """
    
    # Step 1: Initialize Pinecone client and embedding model
    try:
        # Lấy thông tin cấu hình từ các biến môi trường đã tải
        azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        azure_api_key = os.getenv("AZURE_OPENAI_API_KEY")
        pinecone_api_key = os.getenv("PINECONE_API_KEY")

        if not all([azure_endpoint, azure_api_key, pinecone_api_key, os.getenv("AZURE_DEPLOYMENT_NAME")]):
            print("Lỗi: Một hoặc nhiều biến môi trường (AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_DEPLOYMENT_NAME, PINECONE_API_KEY) chưa được thiết lập.")
            print("Vui lòng tạo tệp .env và điền đầy đủ thông tin.")
            return

        client = AzureOpenAI(
            api_version="2024-07-01-preview",
            azure_endpoint=azure_endpoint,
            api_key=azure_api_key,
        )
        pc = Pinecone(
            api_key=pinecone_api_key
        )
        
        print("Đã khởi tạo thành công các clients.")

    except Exception as e:
        print(f"Lỗi khi khởi tạo clients: {e}")
        return

    # Step 2: Create or connect to an index
    index_name = "product-similarity-index"
    embedding_dimension = 1536  # Matches text-embedding-3-small

    if index_name not in [index["name"] for index in pc.list_indexes().indexes]:
        print(f"Đang tạo index mới: {index_name}...")
        try:
            pc.create_index(
                name=index_name,
                dimension=embedding_dimension,
                metric="cosine",  # Explicitly setting cosine similarity
                spec=ServerlessSpec(cloud="aws", region="us-east-1"),
            )
            # Wait for index to be ready
            while not pc.describe_index(index_name).status['ready']:
                print("Đang chờ index sẵn sàng...")
                time.sleep(5)
            print("Tạo index thành công.")
        except Exception as e:
            print(f"Lỗi khi tạo index: {e}")
            return
    else:
        print(f"Đang kết nối đến index có sẵn: {index_name}")

    try:
        index = pc.Index(index_name)
        print("\nThông số index trước khi upsert:")
        print(index.describe_index_stats())

        # Step 3: Upsert sample product vectors into the index
        # Sample dataset embedded in the code
        products = [
            {"id": "prod1", "title": "Red T-Shirt"},
            {"id": "prod2", "title": "Blue Jeans"},
            {"id": "prod3", "title": "Black Leather Jacket"},
            {"id": "prod4", "title": "White Sneakers"},
            {"id": "prod5", "title": "Green Hoodie"},
        ]

        print("\nĐang tạo embeddings và chuẩn bị vectors để upsert...")
        vectors = []
        for p in products:
            embedding = get_embedding(p["title"], client)
            if embedding:
                vectors.append({
                    "id": p["id"],
                    "values": embedding
                })
        
        if not vectors:
            print("Không tạo được vector nào. Đang thoát.")
            return

        print(f"Đang upsert {len(vectors)} vectors vào index...")
        index.upsert(vectors=vectors)
        
        # Nên chờ một lát để việc upsert được index
        time.sleep(10) 
        
        print("\nThông số index sau khi upsert:")
        print(index.describe_index_stats())

        # Step 4: Prepare input query embedding (dummy auto-input)
        query = "clothing item for summer"
        print(f"\nĐang tạo embedding cho truy vấn: '{query}'")
        query_embedding = get_embedding(query, client)

        if not query_embedding:
            print("Không thể tạo embedding cho truy vấn. Đang thoát.")
            return

        # Step 5: Query Pinecone index for top 3 most similar vectors
        top_k = 3
        print(f"Đang truy vấn index để lấy top {top_k} kết quả...")
        results = index.query(
            vector=query_embedding, 
            top_k=top_k,
            include_metadata=False # Chúng ta chỉ lưu ID, không có metadata
        )
        
        print("\n--- Kết quả truy vấn thô ---")
        print(results)
        print("----------------------------")

        # Step 6: Display results
        print(f"\nTop {top_k} sản phẩm tương tự cho truy vấn: '{query}'\n")
        
        if not results.matches:
            print("Không tìm thấy kết quả nào.")
        else:
            for match in results.matches:
                product_id = match.id
                score = match.score
                
                # Tìm chi tiết sản phẩm từ danh sách gốc
                product = next((p for p in products if p["id"] == product_id), None)
                
                if product:
                    print(f"- {product['title']} (Điểm tương đồng: {score:.4f})")
                else:
                    print(f"- Không rõ ID sản phẩm: {product_id} (Điểm tương đồng: {score:.4f})")

    except Exception as e:
        print(f"\nĐã xảy ra lỗi trong quá trình vận hành index: {e}")
    

if __name__ == "__main__":
    main()