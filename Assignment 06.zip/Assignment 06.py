import os
import csv
from dotenv import load_dotenv
from openai import AzureOpenAI
from collections import Counter


# Load environment variables from the .env file
load_dotenv()

# ====== Step 1: Input Data ======
def load_log_entries(input_file):
    with open(input_file, 'r') as file:
        return [line.strip() for line in file if line.strip()]

# ====== Step 2: Heuristic Pre-classifier ======
def initial_classify(text):
    keywords = {
        "traffic": "Traffic",
        "road accident": "Traffic",
        "customer": "Customer Issue",
        "unavailable": "Customer Issue",
        "engine": "Vehicle Issue",
        "vehicle": "Vehicle Issue",
        "rain": "Weather",
        "storm": "Weather",
        "label": "Sorting/Labeling Error",
        "barcode": "Sorting/Labeling Error",
        "wrong turn": "Human Error",
        "reroute": "Human Error",
        "system": "Technical System Failure",
        "glitch": "Technical System Failure",
    }
    for k, v in keywords.items():
        if k in text.lower():
            return v
    return "Other"

# ====== Step 3: Azure OpenAI Setup ======
client = AzureOpenAI( 
    api_version="2024-07-01-preview", 
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"), 
    api_key=os.getenv("AZURE_OPENAI_API_KEY"), 
)

deployment_name = "GPT-4o-mini"  # or whatever your deployment name is

# ====== Step 4: Refinement Layer ======
def refine_classification(text, initial_label):
    prompt = f"""
        You are a logistics assistant. A log entry has been auto-categorized as "{initial_label}".
        Please confirm or correct it by choosing one of the following categories:
            - Traffic
            - Customer Issue
            - Vehicle Issue
            - Weather
            - Sorting/Labeling Error
            - Human Error
            - Technical System Failure
            - Other
        Log Entry: \"\"\"{text}\"\"\"
        Return only the most appropriate category from the list.
    """
    try:
        response = client.chat.completions.create(
            model=deployment_name,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            timeout=10,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"OpenAI error: {e}")
        return initial_label


# ====== Step 5: Final Classification Pipeline ======
def classify_log(text):
    initial = initial_classify(text)
    final = refine_classification(text, initial)
    return {"log": text, "initial": initial, "final": final}

# ====== Step 6: Define function for summary results ======
def summarize_results(results):
    counter = Counter([r["final"] for r in results])
    summary_lines = ["\n=== Summary ==="]
    for category, count in counter.items():
        summary_lines.append(f"{category}: {count}")
    return "\n".join(summary_lines)

# ====== Step 7: Process and Save Results ======
def process_file(input_file, output_file):
    # Load input
    log_entries = load_log_entries(input_file)
    
    # Process entries
    results = []
    output_lines = ["=== Delay Reason Classification Results ==="]
    
    for entry in log_entries:
        result = classify_log(entry)
        results.append(result)
        output_lines.extend([
            f"\nLog Entry: {result['log']}",
            f"Initial Category: {result['initial']}",
            f"Final Category: {result['final']}"
        ])
    
    # Add summary
    output_lines.append(summarize_results(results))
    
    # Save to output file
    with open(output_file, 'w') as file:
        file.write('\n'.join(output_lines))

# ====== Step 8: Main Execution ======
if __name__ == "__main__":
    # Process all three sets of files
    for i in range(1, 4):
        input_file = f"input_{i}.txt"
        output_file = f"output_{i}.txt"
        print(f"\nProcessing {input_file}...")
        process_file(input_file, output_file)
        print(f"Results saved to {output_file}")
