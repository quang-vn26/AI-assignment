# ai_agent_weather_search.py
import os
import time
from langchain.tools import tool
from langchain_openai import AzureChatOpenAI
from langchain_community.utilities import OpenWeatherMapAPIWrapper
from langchain_tavily import TavilySearch
from langgraph.prebuilt import create_react_agent
from dotenv import load_dotenv

# --- Step 1: Setup API keys (Load from .env) ---
load_dotenv()

# Kiểm tra sự tồn tại của các biến môi trường cần thiết
required_vars = ["AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_API_KEY", "AZURE_DEPLOYMENT_NAME", 
                 "OPENWEATHERMAP_API_KEY", "TAVILY_API_KEY"]
if not all(os.getenv(var) for var in required_vars):
    print("Lỗi: Một hoặc nhiều biến môi trường chưa được thiết lập trong tệp .env.")
    exit()

# Thiết lập biến môi trường cho Langchain wrappers (mặc dù đã được load, thiết lập lại 
# để đảm bảo thư viện bên trong có thể truy cập dễ dàng)
os.environ["OPENWEATHERMAP_API_KEY"] = os.getenv("OPENWEATHERMAP_API_KEY")
os.environ["TAVILY_API_KEY"] = os.getenv("TAVILY_API_KEY")


# --- Step 2: Define weather tool using Langchain wrapper ---
# Khởi tạo API Wrapper của OpenWeatherMap
weather_wrapper = OpenWeatherMapAPIWrapper()

@tool
def get_weather(city: str) -> str:
    """
    Get the current weather for a given city.
    
    Args: 
        city (str): The name of the city to get the weather for.
    Returns: 
        str: A string describing the current weather in the specified city, 
             or an error message if the city is not found.
    """
    print(f"-> [Tool Call: get_weather] Đang lấy thời tiết cho: {city}")
    try:
        # Sử dụng wrapper để gọi API
        result = weather_wrapper.run(city)
        print("-> [Tool Result: get_weather] Đã hoàn thành.")
        return result
    except Exception as e:
        # Xử lý lỗi nếu API không tìm thấy thành phố hoặc lỗi khác
        return f"Could not retrieve weather for {city}. Error: {e}"


# --- Step 3: Initialize Tavily search tool ---
tavily_search_tool = TavilySearch(
    max_results=3,  # Tăng kết quả để có câu trả lời tốt hơn
    topic="general",
    description="A powerful tool for searching the web for current, real-time information, news, or general knowledge.",
)
# Đổi tên tool để nó được gọi là "tavily_search" trong nội bộ Langchain
tavily_search_tool.name = "tavily_search"


# --- Step 4: Initialize Azure OpenAI LLM ---
llm = AzureChatOpenAI(
    azure_deployment=os.getenv("AZURE_DEPLOYMENT_NAME"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_version="2024-07-01-preview",
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    temperature=0.0
)


# --- Step 5: Setup Langchain agent with both tools ---
tools = [get_weather, tavily_search_tool]
# Sử dụng create_react_agent từ langgraph để tạo tác nhân có khả năng sử dụng tool
agent = create_react_agent(
    model=llm,
    tools=tools,
)

# --- Conversational Loop Simulation ---
def run_agent_conversation():
    print("=" * 50)
    print("Chào mừng đến với Trợ lý AI. Tác nhân có thể kiểm tra thời tiết và tìm kiếm web.")
    print("=" * 50)

    # Mock user questions for automatic input
    mock_questions = [
        "What's the weather in Hanoi?",
        "Tell me about the latest news in AI in healthcare.",
        "Who won the last World Cup in football? And what's the weather like in Buenos Aires?",
        "What is LangChain?",
        "exit",
    ]
    
    # Duy trì lịch sử tin nhắn để tác nhân có ngữ cảnh
    messages = []
    
    for user_input in mock_questions:
        print(f"\nUser: {user_input}")
        
        if user_input.lower() == "exit":
            print("\nAI: Tạm biệt! Hẹn gặp lại.")
            break
            
        # Thêm tin nhắn người dùng vào lịch sử
        messages.append(("user", user_input))
        
        # Gọi tác nhân (Langgraph agent sử dụng 'messages' là input chính)
        try:
            # Langgraph react agent nhận input dưới dạng dict, thường có key là 'messages'
            response = agent.invoke({"messages": messages})

            # Lấy nội dung phản hồi cuối cùng từ tác nhân
            final_response_content = response["messages"][-1][1] 
            
            # Thêm phản hồi của tác nhân vào lịch sử (role, content)
            messages.append(("assistant", final_response_content))
            
            print(f"AI: {final_response_content}")
            
        except Exception as e:
            print(f"!!! Lỗi khi gọi tác nhân: {e}")
            # Thêm thời gian chờ ngắn giữa các truy vấn
            time.sleep(1) 

if __name__ == "__main__":
    run_agent_conversation()

# Tài liệu: Cách tiếp cận và Thách thức
# 1. Cách tiếp cận:
#    - Thiết lập Môi trường: Sử dụng 'dotenv' để quản lý API keys một cách an toàn.
#    - Khởi tạo LLM: Sử dụng AzureChatOpenAI với mô hình có khả năng lập luận và gọi tool (như GPT-4o-mini).
#    - Định nghĩa Tools:
#        - **get_weather:** Định nghĩa bằng decorator @tool của Langchain, sử dụng OpenWeatherMapAPIWrapper. Đây là tool dành cho truy vấn thời tiết.
#        - **tavily_search_tool:** Sử dụng lớp TavilySearch của Langchain, là tool tìm kiếm web cho các truy vấn thời gian thực.
#    - Tạo Agent: Sử dụng hàm `create_react_agent` từ langgraph. Langgraph/Langchain sử dụng mô hình ReAct (Reasoning and Acting) để cho phép LLM quyết định công cụ nào (weather hoặc search) cần sử dụng dựa trên câu hỏi của người dùng.
#    - Mô phỏng Vòng lặp: Sử dụng danh sách `mock_questions` để tự động hóa đầu vào, mô phỏng một cuộc hội thoại và cập nhật lịch sử `messages` sau mỗi lần trao đổi.

# 2. Thách thức:
#    - **Định dạng Tool:** Đảm bảo hàm `get_weather` có docstring mô tả rõ ràng (bao gồm Args và Returns) để LLM có thể hiểu và gọi nó một cách chính xác.
#    - **Langgraph Output:** Langgraph `create_react_agent` trả về kết quả trong cấu trúc hơi khác so với Langchain AgentExecutor truyền thống, cụ thể là list of tuples/messages. Cần truy cập `response["messages"][-1][1]` để lấy nội dung phản hồi cuối cùng.
#    - **Lỗi API:** Xử lý lỗi gọi tool (ví dụ: thành phố không tồn tại trong OpenWeatherMap) được thêm vào hàm `get_weather` để tác nhân không bị crash.