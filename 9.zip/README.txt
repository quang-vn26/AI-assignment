LAPTOP CONSULTANT CHATBOT
=========================

OVERVIEW:
Automated chatbot that recommends laptops using AI embeddings and Azure OpenAI.

HOW IT WORKS:
1. Creates embeddings for 3 sample laptops
2. Searches for best matches based on user questions
3. Uses AI to generate personalized recommendations

SAMPLE FEATURES:
- PowerMax Ultra: High-performance workstation
- FlexBook Air: Convertible touchscreen laptop
- Home Essential Plus: Budget-friendly option

TESTING:
Runs 3 automated queries without user input.