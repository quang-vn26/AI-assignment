# =============================================================================
# LAPTOP CONSULTANT CHATBOT USING AZURE OPENAI & CHROMADB
# Assignment: Build a Laptop Consultant Chatbot
# Author: VuongPH
# Date: October 18, 2025
# =============================================================================

# pip install openai chromadb  # Run in terminal if needed

import chromadb
from openai import AzureOpenAI
import os
from dotenv import load_dotenv

# Load environment variables from the .env file
load_dotenv()

# =============================================================================
# STEP 1: ENVIRONMENT SETUP (Replace with your STU Azure credentials)
# =============================================================================

# ---- EMBEDDING CONFIG ----
AZURE_OPENAI_EMBEDDING_API_KEY = os.getenv("AZURE_EMBEDDING_OPENAI_API_KEY")
AZURE_OPENAI_EMBEDDING_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_EMBED_MODEL = os.getenv("AZURE_OPENAI_EMBED_MODEL")

# ---- LLM CONFIG ----
AZURE_OPENAI_LLM_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_LLM_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_LLM_MODEL = os.getenv("AZURE_DEPLOYMENT_NAME")

# =============================================================================
# STEP 2: AZURE OPENAI CLIENTS
# =============================================================================
embedding_client = AzureOpenAI(
    api_key=AZURE_OPENAI_EMBEDDING_API_KEY,
    azure_endpoint=AZURE_OPENAI_EMBEDDING_ENDPOINT,
    api_version="2024-07-01-preview"
)

llm_client = AzureOpenAI(
    api_key=AZURE_OPENAI_LLM_API_KEY,
    azure_endpoint=AZURE_OPENAI_LLM_ENDPOINT,
    api_version="2024-07-01-preview"
)

# =============================================================================
# STEP 3: GET EMBEDDING FUNCTION
# =============================================================================
def get_embedding(text):
    try:
        response = embedding_client.embeddings.create(input=text, model=AZURE_OPENAI_EMBED_MODEL)
    except Exception as e:
        print(f"Error: {e}")
        exit()
    return response.data[0].embedding

# =============================================================================
# STEP 4: CALL LLM FUNCTION (Prompt Engineering)
# =============================================================================
def ask_llm(context, user_input):
    """Get recommendation using LLM with RAG context"""
    system_prompt = (
        "You are a helpful assistant specializing in laptop recommendations. "
        "Use the provided context to recommend the best laptop(s) for the user needs."
    )
    user_prompt = (
        f"User requirements: {user_input}\n\n"
        f"Context (top relevant laptops):\n{context}\n\n"
        "Based on the above, which laptop(s) would you recommend and why?"
    )
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
    ]
    response = llm_client.chat.completions.create(
        model=AZURE_OPENAI_LLM_MODEL,
        messages=messages
    )
    return response.choices[0].message.content

# =============================================================================
# STEP 5: CHROMADB SETUP & SAMPLE LAPTOPS
# =============================================================================
chroma_client = chromadb.Client()
collection = chroma_client.create_collection(name="laptops")

# Sample laptops (3 products)
laptops = [
    {
        "id": "1",
        "name": "PowerMax Ultra",
        "description": "Top-tier workstation with AMD Ryzen 9, 64GB RAM, and 2TB NVMe SSD. Excellent for video editing and heavy programming.",
        "tags": "workstation, performance, pro"
    },
    {
        "id": "2",
        "name": "FlexBook Air",
        "description": "Convertible 2-in-1 laptop with Intel i5, 12GB RAM, touchscreen, and 15-hour battery. Perfect for creative professionals.",
        "tags": "convertible, touchscreen, creative"
    },
    {
        "id": "3",
        "name": "Home Essential Plus",
        "description": "Budget-friendly laptop with Intel Pentium, 4GB RAM, 128GB storage. Good for everyday tasks and online learning.",
        "tags": "affordable, compact, daily-use"
    },
]

# Add laptops to ChromaDB with embeddings
print("🔄 Adding laptops to ChromaDB...")
for laptop in laptops:
    embedding = get_embedding(laptop["description"])
    collection.add(
        embeddings=[embedding],
        documents=[laptop["description"]],
        ids=[laptop["id"]],
        metadatas=[{
            "name": laptop["name"],
            "tags": laptop["tags"]
        }],
    )
print("✅ Laptops added successfully!")

# =============================================================================
# STEP 6: AUTOMATED MOCK QUERIES (No input() - Loop through 3 queries)
# =============================================================================
user_queries = [
    "I need a powerful laptop for video editing and running multiple applications simultaneously.",
    "Looking for a versatile laptop with touchscreen for drawing and presentations.",
    "Want an affordable laptop for basic home use like web browsing and documents."
]

def build_context(results, n_context=3):
    """Build context string from ChromaDB results"""
    docs = results["documents"][0]
    metas = results["metadatas"][0]
    context_str = ""
    for doc, meta in zip(docs, metas):
        context_str += (
            f"Name: {meta['name']}\n"
            f"Description: {doc}\n"
            f"Tags: {meta['tags']}\n\n"
        )
    return context_str.strip()

# =============================================================================
# STEP 7: MAIN RAG LOOP (Retrieval-Augmented Generation)
# =============================================================================
print("\n" + "="*60)
print("🏆 LAPTOP RECOMMENDATION RESULTS")
print("="*60)

for user_input in user_queries:
    print(f"\nUser input: {user_input}")
    print("-" * 40)
    
    # Step 1: Retrieve relevant laptops via vector search
    query_embedding = get_embedding(user_input)
    results = collection.query(query_embeddings=[query_embedding], n_results=3)
    
    # Step 2: Build context for LLM
    context = build_context(results)
    
    # Step 3: Get recommendation from LLM
    llm_output = ask_llm(context, user_input)
    
    print("LLM Recommendation:\n")
    print(llm_output)
    print("-" * 40)

print("\n🎉 Chatbot simulation completed!")