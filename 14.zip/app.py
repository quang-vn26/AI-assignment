import os
import sys
from contextlib import redirect_stdout
from typing import TypedDict, Optional, List
from langchain_openai import AzureOpenAIEmbeddings, AzureChatOpenAI
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langgraph.graph import StateGraph, END
from dotenv import load_dotenv

# Load environment variables from .env (if present)
load_dotenv()

# --- AZURE OPENAI CONFIG (Set these in your .env file) ---
# ... (Keep your existing configuration) ...

# --- Step 2: Sample Documents (WALMART) - English ---
WALMART_DOCS = [
    Document(page_content="Walmart customers can return electronics within 30 days with a receipt and original packaging."),
    Document(page_content="Grocery items at Walmart may be returned within 90 days with proof of purchase, except perishable products."),
    Document(page_content="Walmart provides a 1-year warranty for most electronics and home appliances. See product details for exceptions."),
    Document(page_content="Walmart Plus members receive free shipping with no minimum order requirement."),
    Document(page_content="Prescription medications purchased at Walmart are not eligible for return or exchange."),
    Document(page_content="Open-box items are still eligible for return at Walmart within the standard return window, but must include all original accessories."),
    Document(page_content="If a Walmart customer does not have a receipt, most returns will be issued as store credit with valid photo ID."),
    Document(page_content="Walmart allows price matching for identical items found on Walmart.com and local competitors' advertisements."),
    Document(page_content="Items purchased at Walmart Vision Center may be returned or exchanged within 60 days with a receipt."),
    Document(page_content="Returning mobile phones at Walmart requires the device to be unlocked and all personal data removed."),
    Document(page_content="Walmart gift cards cannot be redeemed for cash unless required by law."),
    Document(page_content="Seasonal merchandise at Walmart (e.g., holiday decorations) may have modified return windows; please see in-store signage."),
    Document(page_content="Bicycles purchased at Walmart may be returned within 90 days if not used outdoors and with all accessories included."),
    Document(page_content="For Walmart online orders, customers may return items in-store or by mail using a prepaid label."),
    Document(page_content="Walmart reserves the right to refuse returns if fraud or abuse is suspected."),
]

# --- Step 3: Typed State for LangGraph ---
class RAGState(TypedDict):
    """Define the RAG state for LangGraph"""
    question: str
    context: Optional[str]
    answer: Optional[str]

# --- Step 4: Embedding & Vector Store Setup ---
try:
    embeddings = AzureOpenAIEmbeddings(
        azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
        model=os.getenv("AZURE_OPENAI_EMBED_MODEL"),
        api_version="2024-07-01-preview",
    )
    vectorstore = FAISS.from_documents(
        WALMART_DOCS,
        embeddings,
    )
    retriever = vectorstore.as_retriever(search_kwargs={"k": 3})

except Exception as e:
    print(f"Failed to initialize Azure Embeddings. Please check your .env. Details: {e}")
    exit()

# --- Step 5: Azure Chat Model Setup ---
try:
    llm = AzureChatOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_LLM_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_LLM_API_KEY"),
        deployment_name=os.getenv("AZURE_OPENAI_LLM_MODEL"),
        api_version="2024-07-01-preview",
        temperature=0.2,
    )
except Exception as e:
    print(f"Failed to initialize Azure LLM. Please check your .env. Details: {e}")
    exit()

# --- Step 6: Prompt Template ---
# The prompt guides the LLM to answer in English using the provided context
prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a professional and friendly assistant for Walmart policies and products. "
            "Use the information provided in [CONTEXT] to answer the customer's question in English. "
            "If the information is NOT present in the context, reply: 'Sorry, I could not find specific information about this in the internal policy.'",
        ),
        ("human", "### CONTEXT:\n{context}\n\n### User question: {question}"),
    ]
)

# --- Step 7: Define Nodes for LangGraph ---

def retrieve_node(state: RAGState) -> RAGState:
    """[NODE 1] Retrieve relevant documents from the vector store."""
    print("--- 🔍 START: NODE 1 (RETRIEVE) ---")
    question = state["question"]
    docs: List[Document] = retriever.invoke(question)
    context = "\n- ".join([doc.page_content for doc in docs])
    
    # Node 1 output markers
    print(f"-> Found {len(docs)} relevant documents.")
    print("--- ✅ END: NODE 1 (RETRIEVE) ---")
    return {**state, "context": context}

def generate_node(state: RAGState) -> RAGState:
    """[NODE 2] Generate the answer based on context and question."""
    print("--- 🤖 START: NODE 2 (GENERATE) ---")
    
    formatted_prompt = prompt.format(
        context=state["context"], question=state["question"]
    )
    
    answer = llm.invoke(formatted_prompt)
    
    # Node 2 output markers
    print("-> Finished generating the answer.")
    print("--- ✅ END: NODE 2 (GENERATE) ---")
    return {**state, "answer": answer.content}

# --- Step 8: Build LangGraph (RAG Flow) ---
builder = StateGraph(RAGState)
builder.add_node("retrieve", retrieve_node)
builder.add_node("generate", generate_node)
builder.set_entry_point("retrieve")
builder.add_edge("retrieve", "generate")
builder.set_finish_point("generate")
rag_graph = builder.compile()

# --- Helper class to tee output to both console and file ---
class Tee:
    def __init__(self, file_obj, stdout):
        self.file = file_obj
        self.stdout = stdout

    def write(self, message):
        self.file.write(message)
        self.stdout.write(message)

    def flush(self):
        self.file.flush()
        self.stdout.flush()

# --- 9. Demo run and logging ---
if __name__ == "__main__":
    
    log_filename = "rag_chatbot_session_en.log"
    
    with open(log_filename, 'w', encoding='utf-8') as log_file:
        tee_logger = Tee(log_file, sys.stdout)
        
        with redirect_stdout(tee_logger):

            user_questions = [
                "Can I return the bicycle that I rode outside once?",
                "What is Walmart's return policy for groceries?",
                "Can I get cash back for my gift card?",
                "I don't have a receipt; what can I get when returning an item?",
            ]

            print("--- 🚀 START WALMART POLICY SUPPORT CHATBOT (English data) ---")
            
            for i, user_question in enumerate(user_questions, 1):
                print(f"\n======== CONVERSATION {i}/{len(user_questions)} ========")
                print(f"| ❓ QUESTION: {user_question}")
                print("========================================================")
                
                result = rag_graph.invoke({"question": user_question, "context": None, "answer": None})
                
                print("\n--- 📝 RETRIEVED CONTEXT (FINAL CONTEXT) ---")
                print(result["context"])
                
                print("\n--- ✅ FINAL ANSWER ---")
                print(result["answer"])
                print("========================================================")


            print("\n--- 🏁 END OF RAG CHATBOT DEMO ---")

    print(f"\n--- ✅ All logs saved to file: {log_filename} ---")