# cloud_detector.py
import os
import base64
import io
import requests
import time
from PIL import Image
from langchain_openai import AzureChatOpenAI
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# --- Step 1: Load Configuration and Setup LLM ---
load_dotenv()

# Kiểm tra sự tồn tại của các biến môi trường cần thiết
required_vars = ["AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_API_KEY", "AZURE_DEPLOYMENT_NAME"]
if not all(os.getenv(var) for var in required_vars):
    print("Lỗi: Một hoặc nhiều biến môi trường chưa được thiết lập trong tệp .env.")
    exit()

# Gán biến môi trường cho tiện gọi
AZURE_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_DEPLOYMENT = os.getenv("AZURE_DEPLOYMENT_NAME")


# --- Step 2: Define Structured Output Schema ---
class WeatherResponse(BaseModel):
    """Schema for the LLM's classification output."""
    prediction: str = Field(description="The classification result, must be 'Cloudy' or 'Clear'.")
    accuracy: float = Field(description="The LLM's confidence in its prediction, as a percentage (e.g., 95.0 for 95.0%).")

# --- Setup LLM ---
llm = AzureChatOpenAI(
    azure_endpoint=AZURE_ENDPOINT,
    azure_deployment=AZURE_DEPLOYMENT,
    api_key=AZURE_API_KEY,
    # Cần dùng API version hỗ trợ Multimodal và Structured Output
    api_version="2024-02-15-preview", 
    temperature=0.0 # Giữ nhiệt độ thấp để có kết quả phân loại ổn định
)
llm_with_structured_output = llm.with_structured_output(WeatherResponse)


# --- Utility Functions ---

def get_base64_image_from_url(image_url: str) -> tuple[str, str | None]:
    """Tải ảnh từ URL, mã hóa Base64 và trả về MIME type."""
    try:
        print(f"-> Đang tải ảnh từ URL: {image_url}")
        response = requests.get(image_url, timeout=10)
        response.raise_for_status()  # Báo lỗi nếu mã trạng thái không phải 200
        
        # Xác định MIME type (e.g., image/jpeg)
        content_type = response.headers.get('Content-Type', 'image/jpeg') 
        if not content_type.startswith('image/'):
            raise ValueError(f"URL không trỏ đến hình ảnh. Content-Type: {content_type}")

        # Mã hóa Base64
        image_bytes = response.content
        image_data_base64 = base64.b64encode(image_bytes).decode("utf-8")
        
        return image_data_base64, content_type

    except requests.exceptions.RequestException as e:
        print(f"!!! Lỗi khi tải ảnh: {e}")
        return None, None
    except ValueError as e:
        print(f"!!! Lỗi xử lý ảnh: {e}")
        return None, None

def classify_satellite_image(image_url: str):
    """Thực hiện phân loại ảnh vệ tinh bằng Azure OpenAI."""
    
    image_base64, mime_type = get_base64_image_from_url(image_url)
    
    if not image_base64:
        print("Bỏ qua phân loại do lỗi tải hoặc xử lý ảnh.")
        return

    # --- Prompt Construction ---
    # System Prompt hướng dẫn LLM về nhiệm vụ và định dạng đầu ra
    system_prompt = f"""You are an expert satellite image analysis tool. 
    Your task is to classify the provided satellite image as either 'Clear' (no clouds) or 'Cloudy' (significant cloud cover). 
    Your output must strictly conform to the provided JSON schema, including the prediction and your confidence level (accuracy). 
    Do not provide any explanations outside of the JSON structure."""

    # User Message chứa văn bản hướng dẫn và dữ liệu hình ảnh
    message = [
        {"role": "system", "content": system_prompt},
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": "Classify the scene as either: 'Clear' or 'Cloudy'. Provide your confidence score.",
                },
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:{mime_type};base64,{image_base64}"},
                },
            ],
        },
    ]

    # --- Call Azure OpenAI ---
    print(f"-> Đang gọi Azure OpenAI để phân tích...")
    try:
        start_time = time.time()
        # Gọi mô hình với đầu ra có cấu trúc
        result: WeatherResponse = llm_with_structured_output.invoke(message)
        end_time = time.time()
        
        print("\n" + "="*50)
        print(f"| URL: {image_url[:50]}...")
        print(f"| Kết quả Phân loại:")
        print(f"| -> Dự đoán: {result.prediction.upper()}")
        print(f"| -> Độ chính xác: {result.accuracy:.2f}%")
        print(f"| (Thời gian inference: {end_time - start_time:.2f} giây)")
        print("="*50)

    except Exception as e:
        print(f"!!! Lỗi trong quá trình gọi LLM: {e}")


def main():
    """Chạy phân loại cho danh sách các URL ảnh mẫu."""
    
    # --- Input: 3 mock images (URLs) ---
    mock_image_urls = [
        # 1. Cloudy Image (pexels: Mây xanh)
        "https://images.pexels.com/photos/53594/blue-clouds-day-fluffy-53594.jpeg?cs=srgb&dl=pexels-pixabay-53594.jpg&fm=jpg",
        # 2. Clear Image 
        "https://drscdn.500px.org/photo/76357689/q%3D80_m%3D1024/v2?sig=dad66f63f8619126e0e64d073f7a6f343908396c148c97468f80acbcef99f2df",
        # 3. Partially Cloudy 
        "https://drscdn.500px.org/photo/1083187932/q%3D90_m%3D2048/v2?sig=84c1427c4f17ae57c7542e05ba6331d6e4630f237db475e6febb321bec4cf707"
    ]
    
    print("\n[HỆ THỐNG PHÂN LOẠI ĐÁM MÂY VỆ TINH BẰNG AZURE GPT-4o-MINI]")
    print("-" * 65)

    for i, url in enumerate(mock_image_urls):
        print(f"\n--- Bắt đầu Phân loại Ảnh {i+1}/{len(mock_image_urls)} ---")
        classify_satellite_image(url)
        # Giảm tốc độ để tránh giới hạn rate limit API
        time.sleep(2) 
        
    print("\nQuá trình phân loại đã hoàn thành.")

if __name__ == "__main__":
    main()