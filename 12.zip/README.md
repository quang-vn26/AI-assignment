# Phát hiện Đám mây trên Ảnh Vệ tinh - Azure OpenAI

## Mục tiêu
Phân loại ảnh vệ tinh thành "Cloudy" hoặc "Clear" sử dụng GPT-4o-mini trên Azure OpenAI.

## Cài đặt
```bash
pip install langchain-openai pillow requests pydantic python-dotenv
```

## Cấu hình
Tạo file `.env` với thông tin:
- AZURE_OPENAI_ENDPOINT
- AZURE_OPENAI_API_KEY
- AZURE_DEPLOYMENT_NAME

## Tính năng chính
- Tải ảnh từ URL và mã hóa Base64
- Sử dụng Multimodal LLM để phân tích hình ảnh
- Structured Output với Pydantic cho kết quả JSON
- Trả về prediction và accuracy score

## Chạy chương trình
```bash
python app.py
```