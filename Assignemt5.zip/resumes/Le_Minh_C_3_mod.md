# Le Minh C

**Senior Data Scientist**

leminhc@example.com | +84 912 000 111 | Da Nang, Vietnam

## Profile

Senior Data Scientist with 10+ years building ML systems in e-commerce and advertising. Strong in recommendation systems and MLOps.

## Experience

**Data Scientist**, *AdWise* — Ho Chi Minh City

May 2015 — Feb 2020

- Built predictive models for ad click-through that improved targeting accuracy by 20%.

**Lead Data Scientist**, *ShopMaster* — Da Nang

Mar 2020 — Present

- Architected recommendation engine increasing monthly GMV by 12%.
- Established model CI/CD reducing deployment time from weeks to 2 days.

## Education

**M.Sc. Data Science**, University of Technology — 2014

## Skills

Python, PyTorch, Spark, SQL, ML Ops, Bayesian Methods

## Projects

**Realtime Recommender** — Streaming recommendations using Flink and Kafka.

## Certifications

- TensorFlow Developer Certificate

## Languages

Vietnamese (native), English (professional)

_Generated on 2025-10-26_
