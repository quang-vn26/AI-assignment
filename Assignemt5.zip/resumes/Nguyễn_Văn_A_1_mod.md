# Nguyễn Văn A

**Junior Software Engineer**

nguyenvana@example.com | +84 912 345 678 | Ho Chi Minh City, Vietnam | linkedin.com/in/nguyenvana

## Profile

Recent Computer Science graduate skilled in Python and web development. Passionate about building reliable backend services and learning production-grade systems.

## Experience

**Software Engineering Intern**, *TechStart VN* — Ho Chi Minh City

Jun 2024 — Aug 2024

- Implemented RESTful APIs in Flask used by internal dashboards.
- Reduced data processing time by 30% through query optimization.

## Education

**B.Sc. Computer Science**, University of Science, HCM — 2024

## Skills

Python, Flask, SQL, Git, Docker

## Projects

**E-commerce crawler** — Built a scalable scraper and ETL pipeline for product data.

## Certifications

- AWS Cloud Practitioner

## Languages

Vietnamese (native), English (professional)

_Generated on 2025-10-26_
