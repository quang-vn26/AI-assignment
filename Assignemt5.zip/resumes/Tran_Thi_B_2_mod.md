# Tran Thi B

**Product Manager**

tranthib@example.com | +84 903 123 456 | Hanoi, Vietnam

## Profile

Product Manager with 5+ years in fintech, specializing in payments and merchant products. Data-driven, cross-functional leader.

## Experience

**Associate Product Manager**, *eWallet Co* — Hanoi

Jul 2019 — Dec 2020

- Ran experiments that reduced checkout friction, lifting conversion by 7%.

**Product Manager**, *FinPay* — Hanoi

Jan 2021 — Present

- Led roadmap for merchant onboarding product used by 10k+ merchants.
- Increased merchant activation rate by 18% through UX and funnel improvements.

## Education

**MBA (Part-time)**, RMIT University — 2023

## Skills

Product Strategy, A/B Testing, SQL, Stakeholder Management

## Certifications

- PMI-ACP

## Languages

Vietnamese (native), English (fluent)

_Generated on 2025-10-26_
