"""
resume_generator_llama.py

Build Resume Generation Using LLaMA (local) - OOP, exception handling, auto-inputs for submission.
Requirements:
  - Optionally: pip install llama-cpp-python
  - Place your local LLaMA .gguf file path into MODEL_PATH variable below if you want to use the model.
  - This script will fall back to a deterministic template generator if model cannot be loaded
    (so sample outputs can be produced without an actual model file).
Usage:
  - Run in Jupyter or python env. No interactive input() calls; uses auto sample inputs.
Outputs:
  - Prints generated resumes.
  - Saves each resume as markdown (.md) and plain text (.txt) in ./resumes/
"""

import os
import json
from dataclasses import dataclass, field
from typing import Dict, Optional, Any, List
from datetime import datetime

# Try importing llama_cpp; if not available or model missing, we'll use fallback
_LLAMA_AVAILABLE = False
try:
    from llama_cpp import Llama  # type: ignore
    _LLAMA_AVAILABLE = True
except Exception:
    _LLAMA_AVAILABLE = False


@dataclass
class LlamaModelWrapper:
    """
    Wrapper around llama_cpp.Llama to provide a safe interface.
    If llama_cpp is not available or model path missing, initialization raises.
    """
    model_path: str
    n_ctx: int = 2048
    temperature: float = 0.2
    max_tokens: int = 512
    _client: Optional[Any] = field(default=None, init=False)

    def __post_init__(self):
        # Validate model path
        if not _LLAMA_AVAILABLE:
            raise RuntimeError(
                "llama_cpp is not installed or not importable. "
                "Install with `pip install llama-cpp-python` and ensure environment supports it."
            )
        if not os.path.exists(self.model_path):
            raise FileNotFoundError(f"Model file not found at: {self.model_path}")
        try:
            self._client = Llama(model_path=self.model_path, n_ctx=self.n_ctx)
            # Simple test call could be done but we skip heavy test
        except Exception as e:
            raise RuntimeError(f"Failed to initialize Llama model: {e}")

    def generate(self, prompt: str, max_tokens: Optional[int] = None, temperature: Optional[float] = None) -> str:
        if self._client is None:
            raise RuntimeError("Llama client is not initialized.")
        if max_tokens is None:
            max_tokens = self.max_tokens
        if temperature is None:
            temperature = self.temperature
        try:
            out = self._client(
                prompt,
                max_tokens=max_tokens,
                temperature=temperature,
            )
            # llama_cpp returns choices with 'text'
            text = out.get("choices", [{}])[0].get("text", "")
            return text.strip()
        except Exception as e:
            raise RuntimeError(f"Text generation failed: {e}")


class ResumeGenerator:
    """
    Generates resumes. Accepts a 'model' object conforming to generate(prompt, ...) or
    falls back to a template generator.
    """
    def __init__(self, model: Optional[LlamaModelWrapper] = None):
        self.model = model

    def build_prompt(self, user_info: Dict[str, Any]) -> str:
        """
        Build a detailed prompt for LLM using prompt engineering principles.
        The prompt instructs the model to output a well-structured resume in Markdown.
        """
        # Basic instructions + format specification
        prompt = (
            "You are an expert resume writer. Produce a concise, professional resume in MARKDOWN format.\n"
            "Requirements:\n"
            "- Use the candidate's data provided below.\n"
            "- Write a short 'Profile' (2-4 lines) that tailors strengths to the job title.\n"
            "- Provide clear sections: Contact, Profile, Experience (reverse chronological), Education, Skills, Certifications (if any), Projects (if any), Languages, Hobbies (brief).\n"
            "- For each experience: include role title, company, location, start-end dates, and 3-5 bullet points with achievements (quantified when possible).\n"
            "- Keep resume length to ~1 page for <10 years experience; else 1-2 pages. Use professional tone.\n"
            "- Use consistent date formats (Mon YYYY) and bullets.\n\n"
            "Candidate data (JSON):\n"
            f"{json.dumps(user_info, ensure_ascii=False, indent=2)}\n\n"
            "Produce only the resume in Markdown — do NOT include any commentary or explanation. "
            "If information is missing, infer reasonable generic content but mark inferred content with [inferred]."
        )
        return prompt

    def generate_with_model(self, prompt: str, max_tokens: int = 512) -> str:
        if self.model is None:
            raise RuntimeError("No model available for generation.")
        return self.model.generate(prompt, max_tokens=max_tokens, temperature=0.2)

    def generate_fallback(self, user_info: Dict[str, Any]) -> str:
        """
        Deterministic template-based resume generator used when LLaMA model isn't available.
        Ensures we can produce sample outputs for the assignment.
        """
        # Helper to format dates
        def fmt_date(d):
            if not d:
                return ""
            return d

        name = user_info.get("name", "Candidate Name [inferred]")
        title = user_info.get("target_title", user_info.get("current_title", "Professional"))
        contact_lines = []
        if user_info.get("email"):
            contact_lines.append(user_info["email"])
        if user_info.get("phone"):
            contact_lines.append(user_info["phone"])
        if user_info.get("location"):
            contact_lines.append(user_info["location"])
        if user_info.get("linkedin"):
            contact_lines.append(user_info["linkedin"])

        profile = user_info.get("summary") or (
            f"{title} with experience in {', '.join(user_info.get('keywords', ['relevant areas']))}. "
            "Proven track record delivering measurable results and collaborating cross-functionally."
        )

        experiences = user_info.get("experience", [])
        exp_md = ""
        if experiences:
            # reverse chronological: assume input already in chronological; sort by start if provided
            for exp in experiences[::-1]:
                role = exp.get("role", "Role")
                company = exp.get("company", "Company")
                loc = exp.get("location", "")
                start = exp.get("start", "")
                end = exp.get("end", "Present")
                bullets = exp.get("bullets", [])
                if not bullets:
                    bullets = [
                        f"Managed {exp.get('team_size','a team')} to deliver key projects on time.",
                        f"Improved process or metric by {exp.get('impact','X%')}.",
                    ]
                exp_md += f"**{role}**, *{company}* — {loc}\n\n"
                exp_md += f"{start} — {end}\n\n"
                for b in bullets:
                    exp_md += f"- {b}\n"
                exp_md += "\n"
        else:
            exp_md = "_No formal experience provided. Relevant projects and skills are highlighted below._\n\n"

        education_list = user_info.get("education", [])
        edu_md = ""
        for edu in education_list:
            edu_md += f"**{edu.get('degree','Degree')}**, {edu.get('institution','Institution')} — {edu.get('grad_year','')}\n\n"

        skills = user_info.get("skills", [])
        skills_md = ", ".join(skills) if skills else "Not specified"

        projects = user_info.get("projects", [])
        proj_md = ""
        for p in projects:
            proj_md += f"**{p.get('name','Project')}** — {p.get('desc','Short description')}\n\n"

        certs = user_info.get("certifications", [])
        certs_md = ""
        if certs:
            for c in certs:
                certs_md += f"- {c}\n"

        languages = user_info.get("languages", [])
        langs_md = ", ".join(languages) if languages else "English (fluent)"

        md = f"# {name}\n\n"
        md += f"**{title}**\n\n"
        if contact_lines:
            md += " | ".join(contact_lines) + "\n\n"
        md += f"## Profile\n\n{profile}\n\n"
        md += "## Experience\n\n" + exp_md
        md += "## Education\n\n" + (edu_md or "Not specified\n\n")
        md += f"## Skills\n\n{skills_md}\n\n"
        if projects:
            md += "## Projects\n\n" + proj_md
        if certs_md:
            md += "## Certifications\n\n" + certs_md + "\n"
        md += f"## Languages\n\n{langs_md}\n\n"
        md += f"_Generated on {datetime.utcnow().strftime('%Y-%m-%d')}_\n"
        return md

    def postprocess(self, text: str) -> str:
        """
        Clean model output if needed (trim whitespace, ensure markdown headings, etc.)
        """
        return text.strip()

    def generate_resume(self, user_info: Dict[str, Any], use_model: bool = True) -> str:
        """
        Generate resume using model when available and requested; else fallback.
        """
        if use_model and self.model is not None:
            prompt = self.build_prompt(user_info)
            try:
                raw = self.generate_with_model(prompt)
                out = self.postprocess(raw)
                # If LLM returned something short/empty, fallback to template
                if len(out) < 50:
                    raise RuntimeError("Model output too short, fallback to template.")
                return out
            except Exception as e:
                # log and fallback
                print(f"[Warning] Model generation failed: {e}. Using fallback generator.")
                return self.generate_fallback(user_info)
        else:
            return self.generate_fallback(user_info)

    def save_resume(self, resume_md: str, filename_base: str) -> Dict[str, str]:
        """
        Save resume as .md and .txt under ./resumes/
        Returns paths.
        """
        os.makedirs("resumes", exist_ok=True)
        md_path = os.path.join("resumes", f"{filename_base}.md")
        txt_path = os.path.join("resumes", f"{filename_base}.txt")
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(resume_md)
        # Also save plain text (strip markdown)
        import re
        text_only = re.sub(r"#+", "", resume_md)  # crude
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write(text_only)
        return {"md": md_path, "txt": txt_path}


# -----------------------
# Sample (auto) inputs
# -----------------------

# -----------------------
# Đọc input từ file
# -----------------------
def read_inputs_from_file(filepath: str) -> List[Dict[str, Any]]:
    import re
    blocks = []
    with open(filepath, encoding="utf-8") as f:
        content = f.read()
    # Find all JSON blocks (between { ... })
    matches = re.findall(r"\{[\s\S]*?\}", content)
    for m in matches:
        try:
            blocks.append(json.loads(m))
        except Exception as e:
            print(f"[Warning] Could not parse block: {e}")
    return blocks


# -----------------------
# Runner: Generate resumes for sample inputs
# -----------------------
def run_generator():
    # Configure your model path here if you want to use local LLaMA:
    # Example: MODEL_PATH = "/path/to/llama-3-13b.gguf"
    MODEL_PATH = os.getenv("LLAMA_MODEL_PATH", "models/llama3/llama-2-7b-chat.Q4_K_M.gguf")  # prefer env var; otherwise leave empty

    model_wrapper = None
    if MODEL_PATH:
        try:
            model_wrapper = LlamaModelWrapper(model_path=MODEL_PATH, n_ctx=2048, temperature=0.2, max_tokens=512)
            print(f"[Info] Loaded local LLaMA model from {MODEL_PATH}")
        except Exception as e:
            print(f"[Warning] Could not load LLaMA model: {e}. Proceeding with fallback generator.")
            model_wrapper = None
    else:
        print("[Info] No MODEL_PATH set. Using fallback template generator for sample outputs.")

    generator = ResumeGenerator(model=model_wrapper)

    # Đọc input từ file mới
    input_path = "Sample input.txt"
    if not os.path.exists(input_path):
        print(f"[Error] Input file {input_path} not found. Không có dữ liệu để sinh resume.")
        inputs = []
    else:
        inputs = read_inputs_from_file(input_path)
    results = []
    for idx, sample in enumerate(inputs, start=1):
        print(f"\n>>> [MOD] Generating resume #{idx} for: {sample.get('name')} <<<")
        resume_md = generator.generate_resume(sample, use_model=(model_wrapper is not None))
        fname_base = f"{sample.get('name').replace(' ', '_')}_{idx}_mod"
        paths = generator.save_resume(resume_md, fname_base)
        print(f"[MOD] Resume saved at: {paths}")
        print("\n--- [MOD] Resume Preview (Markdown) ---\n")
        preview_lines = resume_md.splitlines()[:60]
        for line in preview_lines:
            print(line)
        results.append({"name": sample.get("name"), "md": resume_md, "paths": paths})
    return results


if __name__ == "__main__":
    run_generator()
