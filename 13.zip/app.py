import os
import sys  # Đã có
from contextlib import redirect_stdout  # Đã có
from dotenv import load_dotenv
from typing import TypedDict, Annotated

# ... (Tất cả code từ Dòng 6 đến Dòng 137 - phần định nghĩa graph - giữ nguyên y hệt) ...
# ... (Tôi sẽ bỏ qua phần code không đổi cho ngắn gọn) ...

from langchain_core.documents import Document
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langgraph.prebuilt import ToolNode
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from langchain_core.tools import tool

# --- 1. Tải Biến Môi trường ---
load_dotenv()

# --- 2. Dữ liệu Giả lập (Mock Data) ---
mock_chunks = [
    Document(
        page_content="Patients with a sore throat should drink warm fluids and avoid cold beverages."
    ),
    Document(
        page_content="Mild fevers under 38.5°C can often be managed with rest and hydration."
    ),
    Document(
        page_content="If a patient reports dizziness, advise checking their blood pressure and hydration level."
    ),
    Document(
        page_content="Persistent coughs lasting more than 2 weeks should be evaluated for infections or allergies."
    ),
    Document(
        page_content="Patients experiencing fatigue should consider iron deficiency or poor sleep as potential causes."
    ),
]

# --- 3. Thiết lập LLM và Embedding ---
embedding_model = AzureOpenAIEmbeddings(
    model=os.getenv("AZURE_OPENAI_EMBED_MODEL"),
    api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
    azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT"),
    api_version="2024-02-15-preview",
)
llm = AzureChatOpenAI(
    azure_endpoint=os.environ["AZURE_OPENAI_LLM_ENDPOINT"],
    api_key=os.getenv("AZURE_OPENAI_LLM_API_KEY"),
    azure_deployment=os.getenv("AZURE_OPENAI_LLM_MODEL"),
    api_version="2024-02-15-preview",
)

# --- 4. Thiết lập Retriever ---
db = FAISS.from_documents(mock_chunks, embedding_model)
retriever = db.as_retriever()


# --- 5. Định nghĩa Tools (Phân loại rõ ràng) ---

# TOOL 1: RETRIEVE ADVICE - INTERNAL TOOL (Công cụ Nội bộ)
# Dùng để truy vấn KIẾN THỨC Y TẾ CỐ ĐỊNH (RAG từ mock_chunks)
@tool
def retrieve_advice(symptom_query: str) -> str:
    """
    Searches internal documents for relevant patient advice based on symptoms. 
    Use this for basic, pre-defined advice like 'sore throat' or 'mild fever'.
    """
    docs = retriever.invoke(symptom_query)
    return "\n".join(doc.page_content for doc in docs)

# TOOL 2: TAVILY SEARCH - EXTERNAL TOOL (Công cụ Bên ngoài)
# Dùng để truy vấn KIẾN THỨC THỜI GIAN THỰC/MỚI NHẤT (Web Search)
tavily_tool = TavilySearchResults(max_results=2)
tavily_tool.name = "tavily_web_search" # Đổi tên để rõ ràng hơn
tavily_tool.description = (
    "Search the web for up-to-date information on symptoms, treatments, "
    "or complex medical conditions not found in internal documents."
)


# --- 6. Thiết lập Agent (LLM + Tools) ---
tools = [retrieve_advice, tavily_tool]
llm_with_tools = llm.bind_tools(tools)


# --- 7. Định nghĩa State của Graph ---
class AgentState(TypedDict):
    messages: Annotated[list, add_messages]

# --- 8. Định nghĩa các Node của Graph ---
def call_model(state: AgentState):
    messages = state["messages"]
    response = llm_with_tools.invoke(messages)
    return {"messages": [response]}

tool_node = ToolNode(tools)

# --- 9. Định nghĩa Cạnh (Edge) và Luồng (Flow) ---
def should_continue(state: AgentState):
    last_message = state["messages"][-1]
    if last_message.tool_calls:
        return "tools"
    return END

# --- 10. Xây dựng Graph ---
graph_builder = StateGraph(AgentState)
graph_builder.add_node("call_model", call_model)
graph_builder.add_node("tools", tool_node)
graph_builder.add_edge(START, "call_model")
graph_builder.add_conditional_edges(
    "call_model",
    should_continue,
    {"tools": "tools", END: END},
)
graph_builder.add_edge("tools", "call_model")
app = graph_builder.compile()


# --- LỚP HELPER ĐỂ CHIA OUTPUT ---
# (Class này sẽ nhận output và ghi ra 2 nơi)
class Tee:
    def __init__(self, file_obj, stdout):
        self.file = file_obj
        self.stdout = stdout

    def write(self, message):
        self.file.write(message)
        self.stdout.write(message)

    def flush(self):
        # Cần thiết cho redirect_stdout
        self.file.flush()
        self.stdout.flush()

# --- 11. Chạy chương trình VÀ GHI LOG ---
if __name__ == "__main__":
    
    # Tên file log
    log_filename = "chatbot_session.log"
    
    print(f"--- 🚀 Bắt đầu Chạy Chatbot Agent (Log sẽ được ghi vào {log_filename} và hiển thị ở đây) ---")

    # Mở file log với chế độ 'w' (ghi đè)
    with open(log_filename, 'w', encoding='utf-8') as log_file:
        
        # Tạo đối tượng Tee để chia output
        tee_logger = Tee(log_file, sys.stdout)
        
        # Chuyển hướng stdout đến đối tượng Tee
        with redirect_stdout(tee_logger):
            
            # --- BẮT ĐẦU PHẦN CODE GỐC CỦA BẠN ---
            # (Tất cả lệnh print bên trong khối này sẽ đi qua class Tee)
            # (Nó sẽ vừa print ra console, vừa ghi vào file)
            print("--- 🚀 Bắt đầu Chạy Chatbot Agent ---")

            dummy_inputs = [
                HumanMessage(content="Xin chào, tôi cần tư vấn sức khỏe."),
                HumanMessage(content="Tên tôi là An."),
                HumanMessage(content="Tôi 30 tuổi."),
                HumanMessage(content="Tôi bị đau họng và mệt mỏi mấy ngày nay."),
            ]

            SYSTEM_PROMPT = """Bạn là một trợ lý y tế AI hữu ích.
            Nhiệm vụ của bạn là:
            1.  **THU THẬP THÔNG TIN:** Tương tác với bệnh nhân để thu thập đủ 3 thông tin: **Tên**, **Tuổi**, và **Triệu chứng**.
            2.  **HỎI TUẦN TỰ:** Tuyệt đối KHÔNG hỏi tất cả thông tin cùng một lúc. Hãy hỏi từng thứ một.
                - Bắt đầu bằng cách chào và hỏi Tên.
                - Sau khi có Tên, hãy hỏi Tuổi.
                - Sau khi có Tuổi, hãy hỏi Triệu chứng.
            3.  **CUNG CẤP TƯ VẤN:** CHỈ SAU KHI bạn đã thu thập đủ cả 3 thông tin (Tên, Tuổi, Triệu chứng), hãy sử dụng các tool được cung cấp (`retrieve_advice` và `tavily_tool`) để đưa ra lời khuyên y tế sơ bộ dựa trên các triệu chứng.
            4.  Luôn thân thiện và chuyên nghiệp.
            """

            config = {"configurable": {"thread_id": "patient-123"}}
            state = {"messages": [SystemMessage(content=SYSTEM_PROMPT)]}
            
            print(f"[SYSTEM]: {SYSTEM_PROMPT}\n")

            for user_message in dummy_inputs:
                print("---")
                print(f"[Bệnh nhân 🧑]: {user_message.content}")
                
                state["messages"].append(user_message)
                
                result = app.invoke(state, config=config)
                
                ai_response = result["messages"][-1]
                print(f"[Chatbot 🤖]: {ai_response.content}")
                
                state = result

            print("\n--- ✅ Cuộc hội thoại hoàn tất ---")
            print("\nLịch sử hội thoại cuối cùng (Final State):")
            
            for msg in result['messages']:
                if isinstance(msg, SystemMessage):
                    print(f"\n[SYSTEM]\n{msg.content}")
                elif isinstance(msg, HumanMessage):
                    print(f"\n[HUMAN]\n{msg.content}")
                elif isinstance(msg, AIMessage):
                    if msg.tool_calls:
                        print(f"\n[AI thought - Tool Call]\n{msg.tool_calls}")
                    else:
                        print(f"\n[AI response]\n{msg.content}")
            # --- KẾT THÚC PHẦN CODE GỐC CỦA BẠN ---

    # Dòng print này sẽ chỉ in ra console (vì nó nằm ngoài khối `with`)
    print(f"--- ✅ Đã ghi toàn bộ hội thoại vào file: {log_filename} ---")