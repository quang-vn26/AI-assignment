"""
Rewritten Assignment 07 single-file script.

What this script does:
 - Uses facebook/mms-tts-vie model for Vietnamese text-to-speech synthesis (primary method)
 - Demonstrates how to clone a TTS repository (example: coqui/TTS) via git.
 - Shows how to invoke (shell) commands to install dependencies and run an example inference script
   from the cloned repository (commands are provided but commented / guarded so the user controls heavy installs).
 - Provides fallback methods: pyttsx3 (offline TTS) and sine wave generation for guaranteed audio output.

Notes on TTS methods:
 1. facebook/mms-tts-vie (Primary): Best quality Vietnamese TTS using transformers library
    - Requires: pip install transformers torch scipy
    - Download model on first run (~100-200MB)
 2. pyttsx3 (Fallback): Offline TTS using system voices
    - Requires: pip install pyttsx3
    - Works offline, but quality may vary
 3. Sine wave (Final fallback): Simple tone generation
    - No dependencies required
    - Guarantees audio file creation

Usage:
 - First time: pip install transformers torch scipy
 - Run: python "Assignment 07.py"
 - Creates preview.wav and output.wav with Vietnamese speech (if models installed)

Author: (modified from original)
Date: October 26, 2025
"""

import os
import sys
import subprocess
import shutil
import wave
import math
import struct
from pathlib import Path

# Optional imports for advanced TTS
try:
    import torch
    import numpy as np
    from scipy.io.wavfile import write as wav_write
    HAS_ADVANCED_TTS = True
except ImportError:
    HAS_ADVANCED_TTS = False


# ---------- Configuration ----------
REPO_URL = "https://github.com/coqui-ai/TTS.git"  # Example TTS repo to clone (changeable)
CLONE_DIR = Path("tts_clone")
PREVIEW_WAV = Path("preview.wav")
OUTPUT_WAV = Path("output.wav")


def run_shell(cmd, cwd=None, check=True):
    """Run a shell command, print output live. Uses subprocess.run.

    We keep this simple: return the CompletedProcess. Raises CalledProcessError if check=True and command fails.
    """
    print(f"> Running: {cmd} (cwd={cwd})")
    result = subprocess.run(cmd, shell=True, cwd=cwd)
    if check and result.returncode != 0:
        raise subprocess.CalledProcessError(result.returncode, cmd)
    return result


def clone_tts_repo(repo_url=REPO_URL, target_dir=CLONE_DIR):
    """Clone the TTS repository into `target_dir` if it does not already exist.

    This function only performs `git clone` and is safe to call multiple times.
    If `git` is not available or network is blocked, it will raise an exception.
    """
    if target_dir.exists():
        print(f"Repository already cloned at {target_dir.resolve()}")
        return

    # Check git presence
    if shutil.which("git") is None:
        raise EnvironmentError("git is not installed or not found on PATH. Install git to enable cloning.")

    cmd = f"git clone {repo_url} {str(target_dir)}"
    run_shell(cmd)
    print("Clone completed.")


def show_inference_instructions(target_dir=CLONE_DIR):
    """Print simple instructions (commands) to install and run inference inside the cloned repo.

    These commands are examples. Exact steps depend on the repository's README and the environment.
    """
    print("\n==== Example steps to run model inference (manual) ====")
    print(f"cd {str(target_dir)}")
    print("# Create a virtual environment (recommended)")
    print("python -m venv .venv && .venv\\Scripts\\activate  # on Windows (PowerShell)")
    print("# Install requirements (may be large and platform-specific)")
    print("pip install -r requirements.txt")
    print("# Example (repo-specific) - run a provided inference script or notebook")
    print("# python synthesize.py --text 'Xin chao' --out_path output.wav")
    print("# See the repository README for exact commands and model names.\n")


def generate_sine_wave_wav(path: Path, duration_s=1.0, freq=440.0, sample_rate=22050, amplitude=0.5):
    """Generate a simple mono WAV file containing a sine wave.

    This is used as a guaranteed-playable preview audio when heavy TTS inference isn't run.
    """
    num_samples = int(duration_s * sample_rate)
    
    # Generate all samples first
    samples = []
    for i in range(num_samples):
        t = i / sample_rate
        sample = amplitude * math.sin(2 * math.pi * freq * t)
        # Clamp to [-1.0, 1.0] range and convert to 16-bit signed int
        sample = max(-1.0, min(1.0, sample))
        samples.append(int(sample * 32767))
    
    # Convert to bytes
    frames = b''.join(struct.pack('<h', sample) for sample in samples)
    
    # Write all at once
    with wave.open(str(path), 'wb') as wf:
        wf.setnchannels(1)           # mono
        wf.setsampwidth(2)          # 16-bit samples
        wf.setframerate(sample_rate)
        wf.setnframes(num_samples)
        wf.writeframes(frames)
    
    print(f"Generated sine-wave preview: {path.resolve()}")


def generate_chord_wav(path: Path, duration_s=3.0, sample_rate=22050):
    """Generate a mono WAV file containing a chord (multiple frequencies).

    This creates a more interesting sound than a simple sine wave.
    """
    num_samples = int(duration_s * sample_rate)
    amplitude = 0.3  # Lower to prevent clipping with multiple frequencies
    
    # Frequencies for a pleasant chord (C major chord: C, E, G)
    freqs = [261.63, 329.63, 392.00]  # C4, E4, G4
    
    # Generate all samples first
    samples = []
    for i in range(num_samples):
        t = i / sample_rate
        
        # Sum multiple sine waves
        sample = 0.0
        for freq in freqs:
            sample += amplitude * math.sin(2 * math.pi * freq * t)
        
        # Clamp to [-1.0, 1.0] range and convert to 16-bit signed int
        sample = max(-1.0, min(1.0, sample))
        samples.append(int(sample * 32767))
    
    # Convert to bytes
    frames = b''.join(struct.pack('<h', sample) for sample in samples)
    
    # Write all at once
    with wave.open(str(path), 'wb') as wf:
        wf.setnchannels(1)           # mono
        wf.setsampwidth(2)          # 16-bit samples
        wf.setframerate(sample_rate)
        wf.setnframes(num_samples)
        wf.writeframes(frames)
    
    print(f"Generated chord audio: {path.resolve()}")


def try_vits_model_and_save(text: str, out_path: Path) -> bool:
    """Try to use facebook/mms-tts-vie model to save speech. Returns True on success, False otherwise.
    """
    if not HAS_ADVANCED_TTS:
        print("Required libraries not installed. Install with: pip install transformers torch scipy numpy")
        return False
        
    try:
        from transformers import VitsModel, VitsTokenizer
    except ImportError:
        print("transformers library not installed. Install it with: pip install transformers torch scipy")
        return False
    except Exception as e:
        print(f"Failed to import transformers: {e}")
        return False

    try:
        print("Loading facebook/mms-tts-vie model (this may take a moment on first run)...")
        model = VitsModel.from_pretrained("facebook/mms-tts-vie")
        tokenizer = VitsTokenizer.from_pretrained("facebook/mms-tts-vie")
        
        print("Synthesizing speech...")
        inputs = tokenizer(text, return_tensors="pt")
        
        with torch.no_grad():
            output = model(**inputs).waveform
        
        # Convert to numpy and normalize
        import numpy as np
        from scipy.io.wavfile import write as wav_write
        
        audio = output.cpu().numpy()
        audio = audio / np.abs(audio).max()  # Normalize to [-1, 1]
        audio = (audio * 32767).astype(np.int16)  # Convert to 16-bit
        
        # Save the WAV file
        sample_rate = model.config.sampling_rate
        wav_write(str(out_path), sample_rate, audio.squeeze())
        
        if out_path.exists() and out_path.stat().st_size > 0:
            print(f"Saved speech using facebook/mms-tts-vie: {out_path.resolve()}")
            return True
        else:
            print("Model appeared to succeed but file was not created.")
            return False
    except Exception as e:
        print(f"VitsModel failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def try_pyttsx3_and_save(text: str, out_path: Path) -> bool:
    """Try to use pyttsx3 (offline TTS) to save speech. Returns True on success, False otherwise.

    This is optional: pyttsx3 is cross-platform and works offline, but it may not be installed.
    """
    try:
        import pyttsx3
    except ImportError:
        print("pyttsx3 not installed. Installing it would enable TTS functionality.")
        return False
    except Exception:
        return False

    try:
        engine = pyttsx3.init()
        # Make sure the file path is absolute
        abs_path = str(out_path.absolute())
        engine.save_to_file(text, abs_path)
        engine.runAndWait()
        
        # Check if file was actually created
        if out_path.exists() and out_path.stat().st_size > 0:
            print(f"Saved speech preview using pyttsx3: {out_path.resolve()}")
            return True
        else:
            print("pyttsx3 appeared to succeed but file was not created.")
            return False
    except Exception as e:
        print(f"pyttsx3 failed: {e}")
        return False


def create_preview_audio(preview_path=PREVIEW_WAV, force_recreate=False):
    """Create a small preview audio file in the current folder.

    Strategy:
    1) If transformers is installed, try facebook/mms-tts-vie model first
    2) If pyttsx3 is installed and works, use it to synthesize a short Vietnamese phrase.
    3) Otherwise, generate a simple sine wave WAV as a guaranteed fallback.
    """
    if preview_path.exists() and not force_recreate:
        print(f"Preview already exists: {preview_path.resolve()}")
        return

    sample_text = "Xin chào, đây là file xem trước được tạo bởi script."
    
    # Try VitsModel first
    if try_vits_model_and_save(sample_text, preview_path):
        return
    
    # Fallback to pyttsx3
    if try_pyttsx3_and_save(sample_text, preview_path):
        return

    # Fallback: sine wave - create a more interesting sound
    print("Creating fallback sine wave audio...")
    generate_sine_wave_wav(preview_path, duration_s=2.0, freq=440.0)


def create_output_from_text(text: str, out_path=OUTPUT_WAV, force_recreate=False):
    """Create `output.wav` from the provided Vietnamese `text`.

    Strategy:
    - Try facebook/mms-tts-vie model first (best quality for Vietnamese)
    - Try pyttsx3 (offline TTS) as fallback. If available, save speech to `out_path`.
    - If both aren't available or fail, fall back to a longer sine-wave tone so that
      `output.wav` is always present (but this will NOT contain speech).
    """
    if out_path.exists() and not force_recreate:
        print(f"Output already exists: {out_path.resolve()}")
        return

    print(f"Attempting to synthesise speech to {out_path}...")
    
    # Try VitsModel first
    try:
        ok = try_vits_model_and_save(text, out_path)
    except Exception as e:
        print(f"VitsModel synthesis raised an error: {e}")
        ok = False

    if ok:
        print(f"Speech synthesis complete: {out_path.resolve()}")
        return
    
    # Fallback to pyttsx3
    print("Trying pyttsx3 as fallback...")
    try:
        ok = try_pyttsx3_and_save(text, out_path)
    except Exception as e:
        print(f"pyttsx3 synthesis raised an error: {e}")
        ok = False

    if ok:
        print(f"Speech synthesis complete: {out_path.resolve()}")
        return

    # Final fallback: create a longer tone with multiple frequencies
    print("All TTS methods failed — creating a fallback multi-tone as output.wav")
    # Create a more interesting sound with multiple frequencies
    generate_chord_wav(out_path, duration_s=3.0, sample_rate=22050)



def main():
    # Force recreation of audio files
    force_recreate = True
    
    # 1) Create the preview audio right away so the folder contains it (assignment requirement)
    try:
        create_preview_audio(force_recreate=force_recreate)
    except Exception as e:
        print(f"Warning: could not create preview audio automatically: {e}")

    # Prepare a longer Vietnamese text (user requested longer content)
    long_vn_text = (
        "Xin chào! Đây là đoạn văn tiếng Việt dài hơn được sử dụng làm ví dụ cho bài tập TTS. "
        "Mục đích của đoạn văn này là kiểm tra khả năng tổng hợp giọng nói và đảm bảo rằng tệp "
        "output.wav được tạo ra trong cùng thư mục. Nếu pyttsx3 có sẵn, script sẽ lưu giọng nói "
        "thành tệp WAV; nếu không, script sẽ tạo một tông âm thanh làm phương án thay thế."
    )

    # 2.1 Create an output WAV file from the longer Vietnamese text (tries pyttsx3, else fallback tone)
    try:
        create_output_from_text(long_vn_text, force_recreate=force_recreate)
    except Exception as e:
        print(f"Failed to create output.wav: {e}")

    # 2) Attempt to clone a TTS repo (this step is optional and may fail in constrained environments)
    print("\n-- TTS repo cloning is optional. The script will now show how to do it. --\n")

    # We don't call clone_tts_repo() automatically to avoid forcing long downloads in environments where
    # the user didn't want them. Uncomment the following line to perform a live clone.
    # clone_tts_repo()

    # 3) Print instructions for running inference in the cloned repo
    show_inference_instructions()

    # 4) Final note to the user
    print("\nAll done. The file 'preview.wav' is present in the same folder (or will be created on run).\n")
    if OUTPUT_WAV.exists():
        print(f"Also created: {OUTPUT_WAV.resolve()}")
    else:
        print("Note: output.wav was not created. See messages above for why.")


if __name__ == '__main__':
    main()
