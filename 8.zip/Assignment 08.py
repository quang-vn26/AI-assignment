# =============================================================================
# SEMANTIC SEARCH ENGINE FOR CLOTHING PRODUCTS
# Assignment: Building a Semantic Search Engine with Text Embeddings
# Author: [Your Name]
# Date: October 18, 2025
# =============================================================================

import os
from dotenv import load_dotenv
from openai import AzureOpenAI
from scipy.spatial.distance import cosine
from sample_data import products  # Import sample data from separate file

# Load environment variables from the .env file
load_dotenv()

# =============================================================================
# STEP 1: SETUP AZURE OPENAI (Replace with your STU credentials)
# =============================================================================

client = AzureOpenAI(
    api_version="2024-07-01-preview",
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_EMBEDDING_OPENAI_API_KEY"),
)

# =============================================================================
# STEP 3: FUNCTION TO GET EMBEDDINGS FROM AZURE OPENAI
# =============================================================================
def get_embedding(text):
    """Generate embedding for a single text using Azure OpenAI"""
    try:
        response = client.embeddings.create(
            model="text-embedding-3-small",
            input=text
        )
    except Exception as e:
        print(f"Error: {e}")
        exit()
    return response.data[0].embedding

# =============================================================================
# STEP 4: GENERATE EMBEDDINGS FOR ALL PRODUCTS (Pre-compute)
# =============================================================================
print("🔄 Generating embeddings for all products...")
for product in products:
    product["embedding"] = get_embedding(product["description"])
print("✅ Embeddings generated successfully!")

# =============================================================================
# STEP 5: AUTO INPUT QUERIES - More examples
# =============================================================================
queries = [
    "red warm sweater",
    "black jacket",
    "workout pants",
    "white cotton shirt",
    "blue denim jeans"
]

# =============================================================================
# STEP 6: SIMILARITY FUNCTIONS
# =============================================================================
def similarity_score(vec1, vec2):
    """Calculate cosine similarity (1 = identical, 0 = unrelated)"""
    return 1 - cosine(vec1, vec2)

def find_top_matches(query_embedding, top_n=3):
    """Find top N most similar products"""
    scores = []
    for product in products:
        score = similarity_score(query_embedding, product["embedding"])
        scores.append((score, product))
    scores.sort(key=lambda x: x[0], reverse=True)  # Highest similarity first
    return scores[:top_n]

# =============================================================================
# STEP 7: RUN SEARCH FOR EACH AUTO QUERY
# =============================================================================
print("\n" + "="*60)
print("🏆 SEMANTIC SEARCH RESULTS")
print("="*60)

for i, query in enumerate(queries, 1):
    print(f"\n📝 Query {i}: '{query}'")
    print("-" * 40)
    
    # Get query embedding
    query_embedding = get_embedding(query)
    
    # Find top matches
    top_matches = find_top_matches(query_embedding)
    
    for rank, (score, product) in enumerate(top_matches, 1):
        print(f"#{rank} | {product['title']}")
        print(f"   Price: ${product['price']:.2f}")
        print(f"   Similarity: {score:.4f}")
        print()

print("🎉 Search completed successfully!")