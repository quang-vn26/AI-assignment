# =============================================================================
# SAMPLE PRODUCT DATA FOR SEMANTIC SEARCH
# =============================================================================

products = [
    {
        "title": "Blue Jeans",
        "description": "Cotton blue jeans",
        "price": 50.00
    },
    {
        "title": "Red Hoodie",
        "description": "Warm red hoodie jacket",
        "price": 40.00
    },
    {
        "title": "Black Jacket",
        "description": "Black leather jacket",
        "price": 120.00
    },
    {
        "title": "White T-Shirt",
        "description": "White cotton t-shirt",
        "price": 20.00
    },
    {
        "title": "Black Pants",
        "description": "Black workout pants",
        "price": 35.00
    }
]

# Sample queries for testing
sample_queries = [
    "red warm sweater",
    "black jacket",
    "workout pants",
    "cotton clothes",
    "blue denim"
]
