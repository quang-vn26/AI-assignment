SEMANTIC SEARCH ENGINE - REPORT
===============================

1. CÁCH TẠO VÀ SỬ DỤNG EMBEDDINGS:
- Sử dụng mô hình Azure OpenAI "text-embedding-3-small" để tạo embeddings
- Mỗi sản phẩm được chuyển thành một vector số 1536 chiều
- Tìm kiếm bằng cách so sánh độ tương đồng giữa câu hỏi và sản phẩm

2. COSINE SIMILARITY - XẾP HẠNG KẾT QUẢ:
- Điểm từ 0 đến 1
- 1.0 = giống hệt, 0.0 = không liên quan
- Sắp xếp theo điểm từ cao xuống thấp

3. THÁCH THỨC GẶP PHẢI:
- API chậm → Giải pháp: Tính embeddings trước
- Độ chính xác → Cần cải thiện mô hình hoặc mô tả sản phẩm tốt hơn

4. CÁC FILE TRONG PROJECT:
- Assignment 08.py       : File chính chạy chương trình
- sample_data.py         : Chứa dữ liệu sản phẩm mẫu
- input_examples.txt     : Ví dụ về cách sử dụng
- output_example.txt     : Ví dụ kết quả khi chạy chương trình
- README.txt             : Hướng dẫn chi tiết (file này)
- .env                   : Cấu hình API credentials (tự tạo)

5. CÁCH CHẠY CHƯƠNG TRÌNH:
- Cài đặt: pip install openai scipy python-dotenv
- Tạo file .env với Azure OpenAI credentials
- Chạy: python "Assignment 08.py"

6. THÊM SẢN PHẨM MỚI:
- Chỉnh sửa file sample_data.py
- Thêm sản phẩm vào danh sách products